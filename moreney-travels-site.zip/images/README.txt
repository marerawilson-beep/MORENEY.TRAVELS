Photos already placed here (from your screenshots):
3-day-maasai-mara-safari.jpg
4-day-family-beach-break.jpg
4-day-kikambala-beach-escape.jpg
5-day-diani-beach-holiday.jpg
amboseli-elephants.jpg
big-five-game-drive.jpg
blue-lagoon-lodge.jpg
diani-sands-resort.jpg
elephant-trail-lodge.jpg
gallery-beach.jpg
gallery-darter.jpg
gallery-eagle.jpg
gallery-elephant.jpg
gallery-lion.jpg
gallery-palace.jpg
gallery-rhino.jpg
gallery-sunset.jpg
gallery-zebra.jpg
hero.jpg
mara-3-day-safari.jpg
page-d-diani-beach.jpg
page-d-kikambala.jpg
page-d-maasai-mara.jpg
page-kenya-coast.jpg
page-kenya-safari.jpg
page-packages-beach.jpg
page-packages-safari.jpg
palm-cove-guesthouse.jpg
red-earth-lodge.jpg
sultan-palace-apartment.jpg
sultan-palace-studio.jpg
sultan-palace-villa.jpg
tsavo-game-drive.jpg

To replace any photo, save a new .jpg with the same name. Any slot without a file shows a placeholder illustration.
